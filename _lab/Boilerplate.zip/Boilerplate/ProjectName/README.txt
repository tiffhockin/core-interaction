This is the layout you will be expected to use for all your projects this semester.

The first directory you encounter should be a descriptive short project name.



Within this directory you should have a single file named index.html .

The index file will contain the first page of html for any project.  In the case of a one html file project, there will be no need for other .html files.  In the case of multiple html file projects, index.html will link to the other files residing in the "html" directory.





Within this project folder you will have 4 subdirectories / subfolders.

They are:

images 	- for jpegs gifs png etc.

html 	- for any html you create that is linked to index.html

js 	- for any javascript you write or libraries you use

css 	- for any style documents



As needed you may add a "media" folder if your project contains sound or (non-gif) video files.



